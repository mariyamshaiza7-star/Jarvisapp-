plugins { id("com.android.application") }
android { namespace = "com.jarvis.ai"; compileSdk = 34; defaultConfig { applicationId = "com.jarvis.ai"; minSdk = 24; targetSdk = 34 } }
dependencies { implementation("com.squareup.okhttp3:okhttp:4.12.0") }