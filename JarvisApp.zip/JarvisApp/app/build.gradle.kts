plugins { id("com.android.application") }
android {
    namespace = "com.jarvis.ai"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.jarvis.ai"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}
