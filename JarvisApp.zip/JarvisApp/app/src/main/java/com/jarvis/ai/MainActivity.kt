package com.jarvis.ai
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.app.Activity
import android.speech.tts.TextToSpeech
import java.util.Locale
import okhttp3.*
import java.io.IOException
class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private val client = OkHttpClient()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tts = TextToSpeech(this, this)
        val tvResponse = findViewById<TextView>(R.id.tvResponse)
        val etPrompt = findViewById<EditText>(R.id.etPrompt)
        val btnSend = findViewById<Button>(R.id.btnSend)
        btnSend.setOnClickListener {
            val prompt = etPrompt.text.toString()
            if (prompt.isNotEmpty()) {
                tvResponse.text = "Jarvis is thinking..."
                callDeepSeek(prompt, tvResponse)
                etPrompt.text.clear()
            }
        }
    }
    private fun callDeepSeek(prompt: String, tv: TextView) {
        val json = "{\"model\": \"deepseek-chat\", \"messages\": [{\"role\": \"user\", \"content\": \"$prompt\"}]}"
        val body = json.toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url("https://api.deepseek.com/chat/completions").addHeader("Authorization", "Bearer sk-69f6291e774b4232a3c3ed0bed4dd180").post(body).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { runOnUiThread { tv.text = "Error: ${e.message}" } }
            override fun onResponse(call: Call, response: Response) {
                val resp = response.body?.string()
                runOnUiThread {
                    if (response.isSuccessful && resp != null) {
                        val reply = resp.substringAfter("\"content\":\"").substringBefore("\"")
                        tv.text = reply
                        tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null)
                    } else { tv.text = "API Error: ${response.code}" }
                }
            }
        })
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US }
}