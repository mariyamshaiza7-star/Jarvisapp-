package com.jarvis.ai
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.app.Activity
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val tvResponse = findViewById<TextView>(R.id.tvResponse)
        val etPrompt = findViewById<EditText>(R.id.etPrompt)
        val btnSend = findViewById<Button>(R.id.btnSend)
        btnSend.setOnClickListener {
            val prompt = etPrompt.text.toString()
            if (prompt.isNotEmpty()) {
                tvResponse.text = "You said: $prompt"
                etPrompt.text.clear()
            }
        }
    }
}
